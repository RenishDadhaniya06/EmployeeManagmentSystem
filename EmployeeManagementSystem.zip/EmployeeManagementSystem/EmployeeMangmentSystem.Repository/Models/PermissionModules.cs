﻿using System;

namespace EmployeeMangmentSystem.Repository.Models
{
    public class PermissionModules
    {
        public Guid Id { get; set; }

        public string ModuleName { get; set; }
    }
}
