﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeMangmentSystem.Repository.Models.ViewModel
{
    public class RolesViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}
