﻿namespace EmployeeMangmentSystem.Repository.Models
{
    /// <summary>
    /// 
    /// </summary>
    public class Prouct
    {
    }
}